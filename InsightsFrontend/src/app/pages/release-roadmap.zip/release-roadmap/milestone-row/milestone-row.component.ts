import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IssueBarComponent } from '../issue-bar/issue-bar.component';
import { Milestone } from '../../../services/milestone.service';
import { Issue } from '../../../services/issue.service';
import { GitHubStates } from '../../../app.service';

export interface PositionedIssue {
  issue: Issue;
  style: Record<string, string>;
  track: number;
}

@Component({
  selector: 'app-milestone-row',
  standalone: true,
  imports: [CommonModule, IssueBarComponent],
  templateUrl: './milestone-row.component.html',
  styleUrls: ['./milestone-row.component.scss'],
})
export class MilestoneRowComponent implements OnInit {
  @Input({ required: true }) milestone!: Milestone;
  @Input({ required: true }) issues: Issue[] = [];
  @Input({ required: true }) timelineStartDate!: Date;
  @Input({ required: true }) totalTimelineDays!: number;
  @Input() isLast = false;

  public positionedIssues: PositionedIssue[] = [];
  public trackCount = 1;
  public progressPercentage = 0;

  private readonly DEFAULT_POINTS = 3;

  ngOnInit(): void {
    this.calculateProgress();
    if (this.milestone.dueOn) {
      this.planAndLayoutIssues();
    }
  }

  public getIssuesForTrack(trackNumber: number): PositionedIssue[] {
    return this.positionedIssues.filter((p) => p.track === trackNumber);
  }

  public getTracks(): number[] {
    return Array.from({ length: this.trackCount }, (_, index) => index);
  }

  private calculateProgress(): void {
    const total = this.milestone.openIssueCount + this.milestone.closedIssueCount;
    this.progressPercentage = total === 0 ? 0 : Math.round((this.milestone.closedIssueCount / total) * 100);
  }

  private planAndLayoutIssues(): void {
    const closedIssues = this.sortIssuesByPriority(this.issues.filter((index) => index.state === GitHubStates.CLOSED));
    const openIssues = this.sortIssuesByPriority(this.issues.filter((index) => index.state === GitHubStates.OPEN));

    const totalDurationClosed = closedIssues.reduce(
      (accumulator, issue) => accumulator + (issue.points ?? this.DEFAULT_POINTS),
      0,
    );
    const milestoneStartDate = new Date(this.milestone.dueOn!);
    milestoneStartDate.setDate(milestoneStartDate.getDate() - totalDurationClosed);

    // 3. Plan de open issues vanaf het einde van de gesloten issues
    let currentPlanningDate = new Date(milestoneStartDate);

    const issueLayouts: PositionedIssue[] = [];
    const allSortedIssues = [...closedIssues, ...openIssues];

    for (const issue of allSortedIssues) {
      const duration = issue.points ?? this.DEFAULT_POINTS;
      const issueStartDateForCalc = new Date(currentPlanningDate);

      issueLayouts.push({
        issue,
        track: 0, // We gebruiken nu de track-logica hieronder
        style: this.calculateBarPosition(issueStartDateForCalc, duration),
      });

      currentPlanningDate.setDate(currentPlanningDate.getDate() + duration);
    }

    // 4. Verdeel over tracks om overlap te voorkomen
    const finalLayout: PositionedIssue[] = [];
    const tracks: { end: number }[][] = [];

    for (const plannedIssue of issueLayouts) {
      const style = plannedIssue.style;
      const start = Number.parseFloat(style['left']!);
      const width = Number.parseFloat(style['width']!);
      const end = start + width;

      let placed = false;
      for (const [index, track_] of tracks.entries()) {
        const track = track_!;
        const canPlace = track.every((item) => start >= item.end);
        if (canPlace) {
          track.push({ end });
          plannedIssue.track = index;
          finalLayout.push(plannedIssue);
          placed = true;
          break;
        }
      }
      if (!placed) {
        tracks.push([{ end }]);
        plannedIssue.track = tracks.length - 1;
        finalLayout.push(plannedIssue);
      }
    }

    this.trackCount = Math.max(1, tracks.length);
    this.positionedIssues = finalLayout;
  }

  private calculateBarPosition(startDate: Date, durationDays: number): Record<string, string> {
    const endDate = new Date(startDate);
    endDate.setDate(endDate.getDate() + durationDays);
    const timelineEndDate = new Date(this.timelineStartDate);
    timelineEndDate.setDate(timelineEndDate.getDate() + this.totalTimelineDays);

    if (endDate < this.timelineStartDate || startDate > timelineEndDate) return { display: 'none' };

    const clampedStartTime = Math.max(startDate.getTime(), this.timelineStartDate.getTime());
    const clampedEndTime = Math.min(endDate.getTime(), timelineEndDate.getTime());

    const startDays = (clampedStartTime - this.timelineStartDate.getTime()) / (1000 * 3600 * 24);
    const duration = Math.max(1, (clampedEndTime - clampedStartTime) / (1000 * 3600 * 24));

    return {
      left: `${(startDays / this.totalTimelineDays) * 100}%`,
      width: `${(duration / this.totalTimelineDays) * 100}%`,
    };
  }

  private sortIssuesByPriority(issues: Issue[]): Issue[] {
    const priorityOrder: Record<string, number> = { critical: 1, high: 2, medium: 3, low: 4, no: 5 };
    return [...issues].sort((a, b) => {
      const priorityAKey = a.issuePriority?.name.toLowerCase() ?? 'no';
      const priorityBKey = b.issuePriority?.name.toLowerCase() ?? 'no';
      const orderA = priorityOrder[priorityAKey] ?? 6;
      const orderB = priorityOrder[priorityBKey] ?? 6;
      return orderA - orderB;
    });
  }
}
